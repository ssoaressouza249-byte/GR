package com.raylan.grx2x;

interface IShellService {
    void destroy() = 16777114;
    int runSafeScript(String scriptPath) = 1;
    int runSafeCommand(String commandLine) = 2;
}
