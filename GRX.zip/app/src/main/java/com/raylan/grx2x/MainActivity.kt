package com.raylan.grx2x

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.raylan.grx2x.security.SecurityGuard
import com.raylan.grx2x.security.TamperedLockScreen
import com.raylan.grx2x.shizuku.ShizukuConnectionState
import com.raylan.grx2x.ui.AiCreatorScreen
import com.raylan.grx2x.ui.BrandsInjectScreen
import com.raylan.grx2x.ui.GrxTab
import com.raylan.grx2x.ui.GrxViewModel
import com.raylan.grx2x.ui.SensiGeneratorScreen
import com.raylan.grx2x.ui.theme.Grx2xTheme
import com.raylan.grx2x.ui.theme.GrxBackground
import com.raylan.grx2x.ui.theme.GrxCardBorder
import com.raylan.grx2x.ui.theme.GrxCardSurface
import com.raylan.grx2x.ui.theme.GrxEmeraldContainer
import com.raylan.grx2x.ui.theme.GrxPrimarySky
import com.raylan.grx2x.ui.theme.GrxPrimarySkyContainer
import com.raylan.grx2x.ui.theme.GrxSecondaryEmerald
import com.raylan.grx2x.ui.theme.GrxTextMuted
import com.raylan.grx2x.ui.theme.GrxTextPrimary
import com.raylan.grx2x.ui.theme.GrxTextSecondary

class MainActivity : ComponentActivity() {

    private val viewModel: GrxViewModel by viewModels()
    private var integrityState by mutableStateOf(SecurityGuard.IntegrityState(isAuthentic = true))
    private var uninstallPromptedOnce = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        runSecurityCheck()

        setContent {
            Grx2xTheme {
                if (!integrityState.isAuthentic) {
                    TamperedLockScreen(
                        onUninstallClick = { SecurityGuard.triggerUninstallIntent(this) }
                    )
                } else {
                    GrxMainApp(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        runSecurityCheck()
        viewModel.refreshShizuku()
    }

    private fun runSecurityCheck() {
        val result = SecurityGuard.verifyIntegrity(this)
        integrityState = result
        if (!result.isAuthentic && !uninstallPromptedOnce) {
            uninstallPromptedOnce = true
            SecurityGuard.triggerUninstallIntent(this)
        }
    }
}

@Composable
private fun GrxMainApp(viewModel: GrxViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val shizukuState by viewModel.shizukuState.collectAsStateWithLifecycle()

    Scaffold(
        containerColor = GrxBackground,
        contentWindowInsets = WindowInsets.safeDrawing,
        topBar = {
            GrxHeaderBar(shizukuState = shizukuState)
        },
        bottomBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(GrxCardSurface)
            ) {
                HorizontalDivider(thickness = 1.dp, color = GrxCardBorder)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = stringResource(id = R.string.official_credit_line),
                        color = GrxTextMuted,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.testTag("footer_official_credit")
                    )
                }
                NavigationBar(
                    containerColor = GrxCardSurface,
                    tonalElevation = 0.dp
                ) {
                    GrxTab.entries.forEach { tab ->
                        val selected = uiState.activeTab == tab
                        val icon = when (tab) {
                            GrxTab.MARCAS_INJETAR -> Icons.Filled.Bolt
                            GrxTab.GERADOR_SENSI -> Icons.Filled.Tune
                            GrxTab.SISTEMA_IA_CRIADOR -> Icons.Filled.AutoAwesome
                        }
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.selectTab(tab) },
                            icon = {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = tab.label
                                )
                            },
                            label = {
                                Text(
                                    text = tab.label,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = GrxPrimarySky,
                                selectedTextColor = GrxPrimarySky,
                                indicatorColor = GrxPrimarySkyContainer,
                                unselectedIconColor = GrxTextSecondary,
                                unselectedTextColor = GrxTextSecondary
                            ),
                            modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.activeTab) {
                GrxTab.MARCAS_INJETAR -> BrandsInjectScreen(
                    uiState = uiState,
                    onSelectBrand = viewModel::selectBrand,
                    onDetectDeviceAuto = viewModel::detectDeviceAutomatically,
                    onSelectDevice = viewModel::selectDevice,
                    onBackStep = viewModel::goBackInjectStep,
                    onToggleFunction = viewModel::toggleFunction,
                    onSelectGame = viewModel::selectGameTarget,
                    onInjectAndOpen = viewModel::injectAndOpenGame,
                    onDismissResult = viewModel::dismissInjectionResult
                )

                GrxTab.GERADOR_SENSI -> SensiGeneratorScreen(
                    uiState = uiState,
                    onSelectDevice = viewModel::selectSensiDevice,
                    onSelectAimStyle = viewModel::selectSensiAimStyle,
                    onGenerateSensi = viewModel::generateSpecificSensi
                )

                GrxTab.SISTEMA_IA_CRIADOR -> AiCreatorScreen(
                    uiState = uiState,
                    shizukuState = shizukuState,
                    onRequestShizuku = viewModel::requestShizukuConnection,
                    onRefreshDiagnostics = viewModel::refreshDiagnostics,
                    onApplyAiRecommendations = viewModel::applyAiRecommendations,
                    onGoToInjectPanel = { viewModel.selectTab(GrxTab.MARCAS_INJETAR) }
                )
            }
        }
    }
}

@Composable
private fun GrxHeaderBar(shizukuState: ShizukuConnectionState) {
    val isReady = shizukuState == ShizukuConnectionState.CONNECTED_READY

    Surface(
        color = GrxCardSurface,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = GrxPrimarySkyContainer,
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, GrxPrimarySky)
                        ) {
                            Text(
                                text = "2X",
                                color = GrxPrimarySky,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                style = MaterialTheme.typography.labelMedium,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = stringResource(id = R.string.app_name),
                            color = GrxTextPrimary,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold
                        )
                    }
                    Text(
                        text = stringResource(id = R.string.official_credit_line),
                        color = GrxTextSecondary,
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.labelSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.testTag("header_official_credit")
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    color = if (isReady) GrxEmeraldContainer else GrxBackground,
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(
                        1.dp,
                        if (isReady) GrxSecondaryEmerald else GrxCardBorder
                    )
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(7.dp)
                                .background(
                                    color = if (isReady) GrxSecondaryEmerald else GrxTextMuted,
                                    shape = RoundedCornerShape(50)
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isReady) "AIDL ON" else "AIDL OFF",
                            color = if (isReady) GrxSecondaryEmerald else GrxTextSecondary,
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                }
            }
            HorizontalDivider(thickness = 1.dp, color = GrxCardBorder)
        }
    }
}
