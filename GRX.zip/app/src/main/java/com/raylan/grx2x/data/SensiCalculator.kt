package com.raylan.grx2x.data

import kotlin.math.roundToInt

enum class AimStyle(
    val title: String,
    val subtitle: String
) {
    PUXADA_RAPIDA_SMG(
        title = "Puxada Rápida / SMG",
        subtitle = "Arraste ágil para MP40, UMP e troca rápida de perto"
    ),
    EQUILIBRADA_AR(
        title = "Equilibrada / AR",
        subtitle = "Controle firme para SCAR, M4A1 e média distância"
    ),
    PRECISAO_DOZE_AWM(
        title = "Precisão / Doze & AWM",
        subtitle = "Foco cirúrgico para M1887, SPAS12 e mira longa"
    )
}

data class SensiProfile(
    val deviceName: String,
    val brandName: String,
    val aimStyle: AimStyle,
    val geral: Int,
    val pontoVermelho: Int,
    val mira2x: Int,
    val mira4x: Int,
    val miraAwm: Int,
    val olhadinha: Int,
    val dpiRecomendada: Int
) {
    fun formatForClipboard(): String {
        return buildString {
            appendLine("=== GRX 2X • SENSI CALIBRADA ===")
            appendLine("Aparelho: $brandName $deviceName")
            appendLine("Estilo: ${aimStyle.title}")
            appendLine("Geral: $geral")
            appendLine("Ponto Vermelho: $pontoVermelho")
            appendLine("Mira 2x: $mira2x")
            appendLine("Mira 4x: $mira4x")
            appendLine("Mira AWM: $miraAwm")
            appendLine("Olhadinha: $olhadinha")
            appendLine("DPI Recomendada: $dpiRecomendada")
            append("GRX 2X • CRIADOR ORIGINAL: RAYLAN")
        }
    }
}

object SensiCalculator {

    fun calculate(device: DeviceModel, aimStyle: AimStyle): SensiProfile {
        val factor = device.sensitivityFactor
        val hzBoost = when {
            device.refreshRateHz >= 144 -> -4
            device.refreshRateHz >= 120 -> 0
            else -> 6
        }

        val (baseGeral, baseRedDot, base2x, base4x, baseAwm, baseLook, dpiOffset) = when (aimStyle) {
            AimStyle.PUXADA_RAPIDA_SMG -> List7(192, 186, 178, 168, 132, 165, 110)
            AimStyle.EQUILIBRADA_AR -> List7(176, 170, 162, 152, 124, 148, 70)
            AimStyle.PRECISAO_DOZE_AWM -> List7(162, 158, 148, 138, 108, 136, 40)
        }

        fun scale(base: Int, min: Int = 60, max: Int = 200): Int =
            ((base * factor) + hzBoost).roundToInt().coerceIn(min, max)

        val recommendedDpi = (device.defaultDpi + dpiOffset).coerceIn(411, 680)

        return SensiProfile(
            deviceName = device.name,
            brandName = device.brandId.displayName,
            aimStyle = aimStyle,
            geral = scale(baseGeral),
            pontoVermelho = scale(baseRedDot),
            mira2x = scale(base2x),
            mira4x = scale(base4x),
            miraAwm = scale(baseAwm, min = 45, max = 185),
            olhadinha = scale(baseLook, min = 50, max = 195),
            dpiRecomendada = recommendedDpi
        )
    }

    private data class List7(
        val a: Int,
        val b: Int,
        val c: Int,
        val d: Int,
        val e: Int,
        val f: Int,
        val g: Int
    )
}
