package com.raylan.grx2x.data

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.roundToInt

data class DiagnosticSnapshot(
    val freeRamMb: Long,
    val totalRamMb: Long,
    val ramUsagePercent: Int,
    val batteryTempCelsius: Float,
    val thermalStatusLabel: String,
    val analyzedDeviceName: String,
    val recommendedFunctions: Set<GamerFunctionId>,
    val reasoning: String
)

object DeviceDiagnostics {

    fun analyze(context: Context, activeDevice: DeviceModel): DiagnosticSnapshot {
        val (freeMb, totalMb, usagePercent) = readMemoryStats(context)
        val batteryTemp = readBatteryTemperatureCelsius(context)

        val thermalLabel = when {
            batteryTemp >= 41.0f -> "Aquecimento Alto"
            batteryTemp >= 37.5f -> "Morna / Moderada"
            else -> "Temperatura Ideal"
        }

        val recommended = linkedSetOf<GamerFunctionId>()
        val reasons = mutableListOf<String>()

        // Análise de memória RAM em tempo real
        if (freeMb < 1800L || activeDevice.ramGb <= 6 || usagePercent >= 65) {
            recommended.add(GamerFunctionId.LIMPEZA_RAM_EXTREMA)
            reasons.add("RAM livre em ${freeMb} MB ($usagePercent% em uso) pede limpeza imediata de processos")
        }

        // Análise térmica e de chipset
        if (batteryTemp < 40.5f) {
            recommended.add(GamerFunctionId.CPU_TURBO_BOOST)
            recommended.add(GamerFunctionId.GPU_VULKAN_RENDER)
            reasons.add("Térmica em ${batteryTemp.format1()}°C permite CPU Turbo + GPU Vulkan sem throttling")
        } else {
            reasons.add("Térmica elevada (${batteryTemp.format1()}°C): modo focado em resposta tátil sem sobrecarregar CPU")
        }

        // Análise de tela e taxa de atualização
        if (activeDevice.refreshRateHz >= 90) {
            recommended.add(GamerFunctionId.TELA_HZ_CRAVADO)
            reasons.add("Painel de ${activeDevice.refreshRateHz}Hz detectado para travamento de FPS")
        }

        // Resposta tátil e precisão gamer
        recommended.add(GamerFunctionId.TOQUE_ZERO_DELAY)
        recommended.add(GamerFunctionId.AIMBOT_NATIVO_2X)
        if (activeDevice.sensitivityFactor >= 1.0f || activeDevice.touchSamplingHz <= 240) {
            recommended.add(GamerFunctionId.AIMLOCK_ESTABILIZADOR)
            recommended.add(GamerFunctionId.TRICK_HS_100)
        }

        return DiagnosticSnapshot(
            freeRamMb = freeMb,
            totalRamMb = totalMb,
            ramUsagePercent = usagePercent,
            batteryTempCelsius = batteryTemp,
            thermalStatusLabel = thermalLabel,
            analyzedDeviceName = "${activeDevice.brandId.displayName} ${activeDevice.name}",
            recommendedFunctions = recommended,
            reasoning = reasons.joinToString(" • ")
        )
    }

    private fun readMemoryStats(context: Context): Triple<Long, Long, Int> {
        return runCatching {
            val activityManager = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            if (activityManager != null) {
                activityManager.getMemoryInfo(memInfo)
                val totalMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(1L)
                val freeMb = (memInfo.availMem / (1024L * 1024L)).coerceAtLeast(0L)
                val usedPercent = (((totalMb - freeMb).toFloat() / totalMb.toFloat()) * 100f)
                    .roundToInt()
                    .coerceIn(1, 99)
                Triple(freeMb, totalMb, usedPercent)
            } else {
                Triple(2048L, 4096L, 50)
            }
        }.getOrDefault(Triple(2048L, 4096L, 50))
    }

    private fun readBatteryTemperatureCelsius(context: Context): Float {
        return runCatching {
            val batteryIntent = context.registerReceiver(
                null,
                IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            )
            val tenths = batteryIntent?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 340) ?: 340
            (tenths / 10f).coerceIn(15f, 70f)
        }.getOrDefault(34.0f)
    }

    private fun Float.format1(): String = ((this * 10f).roundToInt() / 10f).toString()
}
