package com.raylan.grx2x.ui.theme

import androidx.compose.ui.graphics.Color

val GrxBackground = Color(0xFF0A0C10)
val GrxCardSurface = Color(0xFF12161F)
val GrxElevatedSurface = Color(0xFF171D29)
val GrxCardBorder = Color(0xFF1E293B)

val GrxPrimarySky = Color(0xFF38BDF8)
val GrxPrimarySkyContainer = Color(0xFF0C2D42)
val GrxSecondaryEmerald = Color(0xFF10B981)
val GrxEmeraldContainer = Color(0xFF0B2E24)

val GrxTextPrimary = Color(0xFFF1F5F9)
val GrxTextSecondary = Color(0xFF94A3B8)
val GrxTextMuted = Color(0xFF64748B)

val GrxDangerRed = Color(0xFFDC2626)
val GrxDangerDarkBg = Color(0xFF7F1D1D)
val GrxWarningAmber = Color(0xFFF59E0B)
