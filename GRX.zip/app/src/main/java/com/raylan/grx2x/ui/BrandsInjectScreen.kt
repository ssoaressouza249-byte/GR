package com.raylan.grx2x.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeveloperBoard
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Smartphone
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.raylan.grx2x.R
import com.raylan.grx2x.data.BrandId
import com.raylan.grx2x.data.DeviceCatalog
import com.raylan.grx2x.data.DeviceModel
import com.raylan.grx2x.data.GameTarget
import com.raylan.grx2x.data.GamerFunctionId
import com.raylan.grx2x.shizuku.InjectionResult
import com.raylan.grx2x.ui.theme.GrxBackground
import com.raylan.grx2x.ui.theme.GrxCardBorder
import com.raylan.grx2x.ui.theme.GrxCardSurface
import com.raylan.grx2x.ui.theme.GrxElevatedSurface
import com.raylan.grx2x.ui.theme.GrxEmeraldContainer
import com.raylan.grx2x.ui.theme.GrxPrimarySky
import com.raylan.grx2x.ui.theme.GrxPrimarySkyContainer
import com.raylan.grx2x.ui.theme.GrxSecondaryEmerald
import com.raylan.grx2x.ui.theme.GrxTextMuted
import com.raylan.grx2x.ui.theme.GrxTextPrimary
import com.raylan.grx2x.ui.theme.GrxTextSecondary

@Composable
fun BrandsInjectScreen(
    uiState: GrxUiState,
    onSelectBrand: (BrandId) -> Unit,
    onDetectDeviceAuto: () -> Unit,
    onSelectDevice: (DeviceModel) -> Unit,
    onBackStep: () -> Unit,
    onToggleFunction: (GamerFunctionId) -> Unit,
    onSelectGame: (GameTarget) -> Unit,
    onInjectAndOpen: () -> Unit,
    onDismissResult: () -> Unit
) {
    if (uiState.injectStep > 1 && !uiState.isInjecting) {
        BackHandler { onBackStep() }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GrxBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            StepIndicatorBar(currentStep = uiState.injectStep)

            AnimatedContent(
                targetState = uiState.injectStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "inject_step_transition"
            ) { step ->
                when (step) {
                    1 -> BrandSelectionStep(
                        onSelectBrand = onSelectBrand,
                        onDetectDeviceAuto = onDetectDeviceAuto
                    )

                    2 -> ModelSelectionStep(
                        brandId = uiState.selectedBrand ?: BrandId.MOTOROLA,
                        onBack = onBackStep,
                        onSelectDevice = onSelectDevice
                    )

                    else -> FunctionsInjectionStep(
                        device = uiState.selectedDevice ?: DeviceCatalog.allModels.first(),
                        selectedFunctions = uiState.selectedFunctions,
                        selectedGame = uiState.selectedGame,
                        detectedBanner = uiState.detectedBannerMessage,
                        lastResult = uiState.lastInjectionResult,
                        onBack = onBackStep,
                        onToggleFunction = onToggleFunction,
                        onSelectGame = onSelectGame,
                        onInjectAndOpen = onInjectAndOpen,
                        onDismissResult = onDismissResult
                    )
                }
            }
        }

        if (uiState.isInjecting) {
            InjectionProgressModal(
                deviceName = uiState.selectedDevice?.name ?: "Dispositivo",
                progress = uiState.injectionProgress
            )
        }
    }
}

@Composable
private fun StepIndicatorBar(currentStep: Int) {
    val steps = listOf("1. Marca", "2. Modelo", "3. Painel & Injetar")
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        steps.forEachIndexed { index, label ->
            val stepNum = index + 1
            val isActive = stepNum == currentStep
            val isCompleted = stepNum < currentStep
            val borderColor = when {
                isActive -> GrxPrimarySky
                isCompleted -> GrxSecondaryEmerald
                else -> GrxCardBorder
            }
            val textColor = when {
                isActive -> GrxPrimarySky
                isCompleted -> GrxSecondaryEmerald
                else -> GrxTextMuted
            }
            Surface(
                color = GrxCardSurface,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, borderColor),
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = label,
                    color = textColor,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                )
            }
        }
    }
}

@Composable
private fun BrandSelectionStep(
    onSelectBrand: (BrandId) -> Unit,
    onDetectDeviceAuto: () -> Unit
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item(span = { GridItemSpan(2) }) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Etapa 1 — Escolha a Marca",
                    color = GrxTextPrimary,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Selecione a fabricante para calibrar os scripts .sh específicos do aparelho.",
                    color = GrxTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onDetectDeviceAuto,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GrxPrimarySkyContainer,
                        contentColor = GrxPrimarySky
                    ),
                    border = BorderStroke(1.dp, GrxPrimarySky),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("detect_device_auto_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.PhoneAndroid,
                        contentDescription = "Detectar celular automaticamente",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(id = R.string.detect_device_auto),
                        fontWeight = FontWeight.SemiBold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        items(DeviceCatalog.brands, key = { it.id.name }) { brand ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
                border = BorderStroke(1.dp, GrxCardBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectBrand(brand.id) }
                    .testTag("brand_card_${brand.id.slug}")
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Surface(
                        color = GrxPrimarySkyContainer,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Filled.Smartphone,
                                contentDescription = brand.displayName,
                                tint = GrxPrimarySky,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = brand.displayName,
                        color = GrxTextPrimary,
                        style = MaterialTheme.typography.titleSmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = brand.subtitle,
                        color = GrxTextSecondary,
                        style = MaterialTheme.typography.bodySmall,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "${brand.modelCount} modelos",
                        color = GrxPrimarySky,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }
    }
}

@Composable
private fun ModelSelectionStep(
    brandId: BrandId,
    onBack: () -> Unit,
    onSelectDevice: (DeviceModel) -> Unit
) {
    val models = DeviceCatalog.modelsForBrand(brandId)

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("back_to_brands_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Voltar para marcas",
                        tint = GrxPrimarySky
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "Etapa 2 — ${brandId.displayName}",
                        color = GrxTextPrimary,
                        style = MaterialTheme.typography.titleMedium
                    )
                    Text(
                        text = "Escolha o modelo para calibração dedicada",
                        color = GrxTextSecondary,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
        }

        items(models, key = { it.id }) { model ->
            Card(
                colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
                border = BorderStroke(1.dp, GrxCardBorder),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectDevice(model) }
                    .testTag("model_card_${model.id}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = model.name,
                            color = GrxTextPrimary,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = "${model.chipset} • ${model.ramGb}GB RAM",
                            color = GrxTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Surface(
                        color = GrxElevatedSurface,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, GrxCardBorder)
                    ) {
                        Text(
                            text = "${model.refreshRateHz}Hz",
                            color = GrxPrimarySky,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FunctionsInjectionStep(
    device: DeviceModel,
    selectedFunctions: Set<GamerFunctionId>,
    selectedGame: GameTarget,
    detectedBanner: String?,
    lastResult: InjectionResult?,
    onBack: () -> Unit,
    onToggleFunction: (GamerFunctionId) -> Unit,
    onSelectGame: (GameTarget) -> Unit,
    onInjectAndOpen: () -> Unit,
    onDismissResult: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
                border = BorderStroke(1.dp, GrxPrimarySky.copy(alpha = 0.45f)),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier.testTag("back_to_models_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Voltar para modelos",
                            tint = GrxPrimarySky
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${device.brandId.displayName} ${device.name}",
                            color = GrxTextPrimary,
                            style = MaterialTheme.typography.titleMedium,
                            modifier = Modifier.testTag("selected_device_title")
                        )
                        Text(
                            text = "${device.chipset} • ${device.refreshRateHz}Hz • ${device.touchSamplingHz}Hz Touch",
                            color = GrxPrimarySky,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    Surface(
                        color = GrxEmeraldContainer,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, GrxSecondaryEmerald.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "${selectedFunctions.size}/8",
                            color = GrxSecondaryEmerald,
                            style = MaterialTheme.typography.labelMedium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        if (!detectedBanner.isNullOrBlank()) {
            item {
                Surface(
                    color = GrxPrimarySkyContainer,
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, GrxPrimarySky.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = detectedBanner,
                        color = GrxPrimarySky,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        if (lastResult != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxEmeraldContainer),
                    border = BorderStroke(1.dp, GrxSecondaryEmerald),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = "Concluído",
                            tint = GrxSecondaryEmerald,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = lastResult.message,
                                color = GrxTextPrimary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        OutlinedButton(
                            onClick = onDismissResult,
                            border = BorderStroke(1.dp, GrxSecondaryEmerald),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "OK",
                                color = GrxSecondaryEmerald,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }

        items(GamerFunctionId.entries, key = { it.name }) { fn ->
            val checked = selectedFunctions.contains(fn)
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (checked) GrxElevatedSurface else GrxCardSurface
                ),
                border = BorderStroke(
                    width = 1.dp,
                    color = if (checked) GrxPrimarySky.copy(alpha = 0.7f) else GrxCardBorder
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onToggleFunction(fn) }
                    .testTag("function_card_${fn.slug}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = if (checked) GrxPrimarySkyContainer else GrxBackground,
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, GrxCardBorder),
                        modifier = Modifier.size(40.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = functionIcon(fn),
                                contentDescription = fn.title,
                                tint = if (checked) GrxPrimarySky else GrxTextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = fn.title,
                            color = GrxTextPrimary,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Text(
                            text = fn.description,
                            color = GrxTextSecondary,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Switch(
                        checked = checked,
                        onCheckedChange = { onToggleFunction(fn) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = GrxBackground,
                            checkedTrackColor = GrxSecondaryEmerald,
                            uncheckedThumbColor = GrxTextSecondary,
                            uncheckedTrackColor = GrxBackground,
                            uncheckedBorderColor = GrxCardBorder
                        ),
                        modifier = Modifier.testTag("function_switch_${fn.slug}")
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Versão do Jogo",
                color = GrxTextSecondary,
                style = MaterialTheme.typography.labelMedium
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                GameTarget.entries.forEach { target ->
                    val isSelected = selectedGame == target
                    Surface(
                        color = if (isSelected) GrxPrimarySkyContainer else GrxCardSurface,
                        shape = RoundedCornerShape(50),
                        border = BorderStroke(
                            1.dp,
                            if (isSelected) GrxPrimarySky else GrxCardBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .clip(RoundedCornerShape(50))
                            .clickable { onSelectGame(target) }
                            .testTag("game_pill_${target.name.lowercase()}")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = target.label,
                                color = if (isSelected) GrxPrimarySky else GrxTextSecondary,
                                style = MaterialTheme.typography.titleSmall
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onInjectAndOpen,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GrxSecondaryEmerald,
                    contentColor = GrxBackground
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("inject_and_open_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.PlayArrow,
                    contentDescription = "Injetar e abrir jogo",
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = stringResource(id = R.string.inject_and_open_game),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    letterSpacing = 0.5.sp
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun InjectionProgressModal(
    deviceName: String,
    progress: Int
) {
    Dialog(
        onDismissRequest = {},
        properties = DialogProperties(
            dismissOnBackPress = false,
            dismissOnClickOutside = false
        )
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
            border = BorderStroke(1.dp, GrxPrimarySky),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("injection_progress_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Filled.RocketLaunch,
                    contentDescription = "Aplicando otimizações",
                    tint = GrxSecondaryEmerald,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "$progress%",
                    color = GrxPrimarySky,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 32.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { (progress / 100f).coerceIn(0f, 1f) },
                    color = GrxSecondaryEmerald,
                    trackColor = GrxBackground,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(8.dp)
                        .clip(RoundedCornerShape(4.dp))
                )
                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Ativando otimizações e scripts .sh para $deviceName...",
                    color = GrxTextPrimary,
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Execução segura via Shizuku AIDL",
                    color = GrxTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

private fun functionIcon(functionId: GamerFunctionId): ImageVector = when (functionId) {
    GamerFunctionId.AIMBOT_NATIVO_2X -> Icons.Filled.CenterFocusStrong
    GamerFunctionId.AIMLOCK_ESTABILIZADOR -> Icons.Filled.TrackChanges
    GamerFunctionId.TRICK_HS_100 -> Icons.Filled.Tune
    GamerFunctionId.CPU_TURBO_BOOST -> Icons.Filled.Bolt
    GamerFunctionId.GPU_VULKAN_RENDER -> Icons.Filled.DeveloperBoard
    GamerFunctionId.TOQUE_ZERO_DELAY -> Icons.Filled.TouchApp
    GamerFunctionId.TELA_HZ_CRAVADO -> Icons.Filled.Speed
    GamerFunctionId.LIMPEZA_RAM_EXTREMA -> Icons.Filled.CleaningServices
}
