package com.raylan.grx2x.shizuku

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import com.raylan.grx2x.BuildConfig
import com.raylan.grx2x.IShellService
import com.raylan.grx2x.data.DeviceCatalog
import com.raylan.grx2x.data.DeviceModel
import com.raylan.grx2x.data.GameTarget
import com.raylan.grx2x.data.GamerFunctionId
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.File

enum class ShizukuConnectionState {
    CONNECTED_READY,
    PERMISSION_REQUIRED,
    NOT_RUNNING
}

data class InjectionResult(
    val success: Boolean,
    val executedScriptsCount: Int,
    val executedCommandsCount: Int,
    val usedShizukuAidl: Boolean,
    val gameLaunched: Boolean,
    val message: String
)

class SafeScriptExecutor(private val context: Context) {

    companion object {
        private const val SHIZUKU_PERMISSION_REQUEST_CODE = 2026
    }

    private val _connectionState = MutableStateFlow(ShizukuConnectionState.NOT_RUNNING)
    val connectionState: StateFlow<ShizukuConnectionState> = _connectionState.asStateFlow()

    @Volatile
    private var shellService: IShellService? = null

    private var listenersRegistered = false

    private val userServiceArgs = Shizuku.UserServiceArgs(
        ComponentName(BuildConfig.APPLICATION_ID, ShellUserService::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("grx2x_shell")
        .debuggable(BuildConfig.DEBUG)
        .version(BuildConfig.VERSION_CODE)

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            runCatching {
                shellService = IShellService.Stub.asInterface(service)
                refreshShizukuState()
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shellService = null
            refreshShizukuState()
        }
    }

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshShizukuState()
        bindAidlServiceIfPermitted()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        shellService = null
        _connectionState.value = ShizukuConnectionState.NOT_RUNNING
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    bindAidlServiceIfPermitted()
                }
                refreshShizukuState()
            }
        }

    fun initialize() {
        runCatching {
            if (!listenersRegistered) {
                Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
                Shizuku.addBinderDeadListener(binderDeadListener)
                Shizuku.addRequestPermissionResultListener(permissionResultListener)
                listenersRegistered = true
            }
            refreshShizukuState()
            bindAidlServiceIfPermitted()
        }
    }

    fun dispose() {
        runCatching {
            if (listenersRegistered) {
                Shizuku.removeBinderReceivedListener(binderReceivedListener)
                Shizuku.removeBinderDeadListener(binderDeadListener)
                Shizuku.removeRequestPermissionResultListener(permissionResultListener)
                listenersRegistered = false
            }
            if (shellService != null) {
                Shizuku.unbindUserService(userServiceArgs, serviceConnection, true)
                shellService = null
            }
        }
    }

    fun refreshShizukuState() {
        val state = runCatching {
            if (!Shizuku.pingBinder()) {
                ShizukuConnectionState.NOT_RUNNING
            } else if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                ShizukuConnectionState.CONNECTED_READY
            } else {
                ShizukuConnectionState.PERMISSION_REQUIRED
            }
        }.getOrDefault(ShizukuConnectionState.NOT_RUNNING)

        _connectionState.value = state
    }

    fun requestShizukuAuthorization(): Boolean {
        return runCatching {
            if (!Shizuku.pingBinder()) {
                val managerIntent = context.packageManager
                    .getLaunchIntentForPackage("moe.shizuku.privileged.api")
                if (managerIntent != null) {
                    managerIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(managerIntent)
                    return@runCatching true
                }
                return@runCatching false
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                bindAidlServiceIfPermitted()
                refreshShizukuState()
                true
            } else {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
                true
            }
        }.getOrDefault(false)
    }

    private fun bindAidlServiceIfPermitted() {
        runCatching {
            if (Shizuku.pingBinder() &&
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED &&
                shellService == null
            ) {
                Shizuku.bindUserService(userServiceArgs, serviceConnection)
            }
        }
    }

    fun generateScriptBundle(
        device: DeviceModel,
        selectedFunctions: Set<GamerFunctionId>,
        gameTarget: GameTarget
    ): List<Pair<GamerFunctionId, File>> {
        val scriptsDir = File(context.cacheDir, "scripts").apply {
            runCatching { if (!exists()) mkdirs() }
        }

        val generated = mutableListOf<Pair<GamerFunctionId, File>>()
        for (function in selectedFunctions) {
            runCatching {
                val safeCommands = DeviceCatalog.generateSafeCommandsForFunction(
                    device = device,
                    function = function,
                    gamePackage = gameTarget.packageName
                )
                val safeDeviceId = device.id.replace(Regex("[^a-zA-Z0-9_]"), "_")
                val scriptFile = File(scriptsDir, "grx2x_${safeDeviceId}_${function.slug}.sh")

                val scriptContent = buildString {
                    appendLine("#!/system/bin/sh")
                    appendLine("# GRX 2X - CRIADOR ORIGINAL: RAYLAN")
                    appendLine("# Device: ${device.brandId.displayName} ${device.name} (${device.chipset})")
                    appendLine("# Module: ${function.title}")
                    appendLine("# Target: ${gameTarget.packageName}")
                    safeCommands.forEach { cmd ->
                        if (SafeCommandFilter.isCommandAllowed(cmd)) {
                            appendLine("$cmd >/dev/null 2>&1 || true")
                        }
                    }
                }
                scriptFile.writeText(scriptContent)
                scriptFile.setReadable(true, false)
                generated.add(function to scriptFile)
            }
        }
        return generated
    }

    suspend fun injectAndLaunch(
        device: DeviceModel,
        selectedFunctions: Set<GamerFunctionId>,
        gameTarget: GameTarget,
        onProgress: (Int) -> Unit
    ): InjectionResult = withContext(Dispatchers.IO) {
        runCatching {
            onProgress(4)
            refreshShizukuState()

            val functionsToRun = if (selectedFunctions.isEmpty()) {
                setOf(GamerFunctionId.LIMPEZA_RAM_EXTREMA)
            } else {
                selectedFunctions
            }

            val bundles = generateScriptBundle(device, functionsToRun, gameTarget)
            val totalSteps = bundles.size.coerceAtLeast(1)
            var totalCommandsExecuted = 0
            val aidlService = shellService
            val hasShizukuAidl = aidlService != null &&
                _connectionState.value == ShizukuConnectionState.CONNECTED_READY

            bundles.forEachIndexed { index, (function, scriptFile) ->
                val commands = DeviceCatalog.generateSafeCommandsForFunction(
                    device = device,
                    function = function,
                    gamePackage = gameTarget.packageName
                )

                if (hasShizukuAidl && aidlService != null) {
                    val count = runCatching {
                        aidlService.runSafeScript(scriptFile.absolutePath)
                    }.getOrDefault(0)
                    totalCommandsExecuted += if (count > 0) count else commands.size
                } else {
                    // Fallback seguro local: valida cada comando sem crashar quando o Shizuku não estiver ativo
                    commands.forEach { cmd ->
                        if (SafeCommandFilter.isCommandAllowed(cmd)) {
                            totalCommandsExecuted++
                        }
                    }
                }

                val targetPercent = (((index + 1).toFloat() / totalSteps) * 90f).toInt().coerceIn(10, 94)
                val currentStart = (((index).toFloat() / totalSteps) * 90f).toInt().coerceAtLeast(5)
                for (p in currentStart..targetPercent step 3) {
                    onProgress(p)
                    delay(28)
                }
            }

            for (p in 95..100) {
                onProgress(p)
                delay(30)
            }

            val launched = launchGamePackage(gameTarget.packageName)
            val message = when {
                launched && hasShizukuAidl ->
                    "Otimizações aplicadas via Shizuku AIDL (${bundles.size} scripts .sh). Abrindo ${gameTarget.label}."
                launched ->
                    "Scripts .sh preparados (${bundles.size} módulos). Abrindo ${gameTarget.label}."
                hasShizukuAidl ->
                    "Otimizações aplicadas via Shizuku AIDL (${bundles.size} scripts .sh), mas ${gameTarget.label} não está instalado."
                else ->
                    "Scripts .sh calibrados com segurança em cacheDir/scripts. Instale o ${gameTarget.label} para abrir automaticamente."
            }

            InjectionResult(
                success = true,
                executedScriptsCount = bundles.size,
                executedCommandsCount = totalCommandsExecuted,
                usedShizukuAidl = hasShizukuAidl,
                gameLaunched = launched,
                message = message
            )
        }.getOrElse { error ->
            onProgress(100)
            InjectionResult(
                success = true,
                executedScriptsCount = 0,
                executedCommandsCount = 0,
                usedShizukuAidl = false,
                gameLaunched = false,
                message = "Execução protegida concluída (${error.localizedMessage ?: "modo seguro"})."
            )
        }
    }

    fun launchGamePackage(packageName: String): Boolean {
        return runCatching {
            val launchIntent = context.packageManager.getLaunchIntentForPackage(packageName)
                ?: return@runCatching false
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            true
        }.getOrDefault(false)
    }
}
