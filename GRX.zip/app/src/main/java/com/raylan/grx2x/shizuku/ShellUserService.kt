package com.raylan.grx2x.shizuku

import com.raylan.grx2x.IShellService
import java.io.File
import kotlin.system.exitProcess

class ShellUserService : IShellService.Stub() {

    override fun destroy() {
        runCatching { exitProcess(0) }
    }

    override fun runSafeScript(scriptPath: String?): Int {
        if (scriptPath.isNullOrBlank()) return -1
        return runCatching {
            val file = File(scriptPath)
            if (!file.exists() || !file.isFile) return@runCatching -2

            val lines = file.readLines()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("#") }

            var executedCount = 0
            for (line in lines) {
                val rawCommand = line.substringBefore(" >/dev/null").trim()
                if (SafeCommandFilter.isCommandAllowed(rawCommand)) {
                    runCatching {
                        val process = ProcessBuilder("sh", "-c", "$rawCommand >/dev/null 2>&1 || true")
                            .redirectErrorStream(true)
                            .start()
                        process.waitFor()
                        executedCount++
                    }
                }
            }
            executedCount
        }.getOrDefault(-1)
    }

    override fun runSafeCommand(commandLine: String?): Int {
        if (commandLine.isNullOrBlank()) return -1
        if (!SafeCommandFilter.isCommandAllowed(commandLine)) return -3
        return runCatching {
            val process = ProcessBuilder("sh", "-c", "${commandLine.trim()} >/dev/null 2>&1 || true")
                .redirectErrorStream(true)
                .start()
            process.waitFor()
        }.getOrDefault(0)
    }
}
