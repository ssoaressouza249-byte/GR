package com.raylan.grx2x.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raylan.grx2x.R
import com.raylan.grx2x.data.AimStyle
import com.raylan.grx2x.data.BrandId
import com.raylan.grx2x.data.DeviceCatalog
import com.raylan.grx2x.data.DeviceModel
import com.raylan.grx2x.data.SensiProfile
import com.raylan.grx2x.ui.theme.GrxBackground
import com.raylan.grx2x.ui.theme.GrxCardBorder
import com.raylan.grx2x.ui.theme.GrxCardSurface
import com.raylan.grx2x.ui.theme.GrxElevatedSurface
import com.raylan.grx2x.ui.theme.GrxEmeraldContainer
import com.raylan.grx2x.ui.theme.GrxPrimarySky
import com.raylan.grx2x.ui.theme.GrxPrimarySkyContainer
import com.raylan.grx2x.ui.theme.GrxSecondaryEmerald
import com.raylan.grx2x.ui.theme.GrxTextPrimary
import com.raylan.grx2x.ui.theme.GrxTextSecondary

@Composable
fun SensiGeneratorScreen(
    uiState: GrxUiState,
    onSelectDevice: (DeviceModel) -> Unit,
    onSelectAimStyle: (AimStyle) -> Unit,
    onGenerateSensi: () -> Unit
) {
    val context = LocalContext.current
    var brandExpanded by remember { mutableStateOf(false) }
    var modelExpanded by remember { mutableStateOf(false) }
    var copiedFeedback by remember { mutableStateOf(false) }

    val activeBrand = uiState.sensiDevice.brandId
    val modelsInBrand = remember(activeBrand) { DeviceCatalog.modelsForBrand(activeBrand) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GrxBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            item {
                Text(
                    text = "Gerador de Sensibilidade",
                    color = GrxTextPrimary,
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Cálculo calibrado por tela, taxa de toque e DPI para o seu aparelho.",
                    color = GrxTextSecondary,
                    style = MaterialTheme.typography.bodySmall
                )
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
                    border = BorderStroke(1.dp, GrxCardBorder),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Marca e Modelo",
                            color = GrxPrimarySky,
                            style = MaterialTheme.typography.labelMedium
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { brandExpanded = true },
                                    border = BorderStroke(1.dp, GrxCardBorder),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("sensi_brand_selector")
                                ) {
                                    Text(
                                        text = activeBrand.displayName,
                                        color = GrxTextPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = Icons.Filled.ExpandMore,
                                        contentDescription = "Selecionar marca",
                                        tint = GrxPrimarySky
                                    )
                                }
                                DropdownMenu(
                                    expanded = brandExpanded,
                                    onDismissRequest = { brandExpanded = false },
                                    modifier = Modifier.background(GrxElevatedSurface)
                                ) {
                                    BrandId.entries.forEach { brand ->
                                        DropdownMenuItem(
                                            text = { Text(brand.displayName, color = GrxTextPrimary) },
                                            onClick = {
                                                brandExpanded = false
                                                val firstModel = DeviceCatalog.modelsForBrand(brand).first()
                                                onSelectDevice(firstModel)
                                            }
                                        )
                                    }
                                }
                            }

                            Box(modifier = Modifier.weight(1f)) {
                                OutlinedButton(
                                    onClick = { modelExpanded = true },
                                    border = BorderStroke(1.dp, GrxCardBorder),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp)
                                        .testTag("sensi_model_selector")
                                ) {
                                    Text(
                                        text = uiState.sensiDevice.name,
                                        color = GrxTextPrimary,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Icon(
                                        imageVector = Icons.Filled.ExpandMore,
                                        contentDescription = "Selecionar modelo",
                                        tint = GrxPrimarySky
                                    )
                                }
                                DropdownMenu(
                                    expanded = modelExpanded,
                                    onDismissRequest = { modelExpanded = false },
                                    modifier = Modifier.background(GrxElevatedSurface)
                                ) {
                                    modelsInBrand.forEach { model ->
                                        DropdownMenuItem(
                                            text = { Text(model.name, color = GrxTextPrimary) },
                                            onClick = {
                                                modelExpanded = false
                                                onSelectDevice(model)
                                            }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
                    border = BorderStroke(1.dp, GrxCardBorder),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = "Estilo de Mira",
                            color = GrxPrimarySky,
                            style = MaterialTheme.typography.labelMedium
                        )
                        AimStyle.entries.forEach { style ->
                            val selected = uiState.sensiAimStyle == style
                            Surface(
                                color = if (selected) GrxPrimarySkyContainer else GrxBackground,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(
                                    1.dp,
                                    if (selected) GrxPrimarySky else GrxCardBorder
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { onSelectAimStyle(style) }
                                    .testTag("aim_style_${style.name.lowercase()}")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.GpsFixed,
                                        contentDescription = style.title,
                                        tint = if (selected) GrxPrimarySky else GrxTextSecondary,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = style.title,
                                            color = if (selected) GrxPrimarySky else GrxTextPrimary,
                                            style = MaterialTheme.typography.titleSmall
                                        )
                                        Text(
                                            text = style.subtitle,
                                            color = GrxTextSecondary,
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Button(
                    onClick = {
                        copiedFeedback = false
                        onGenerateSensi()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GrxPrimarySky,
                        contentColor = GrxBackground
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("generate_sensi_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.Tune,
                        contentDescription = "Gerar sensibilidade específica",
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = stringResource(id = R.string.generate_specific_sensi),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            val profile = uiState.generatedSensi
            if (profile != null) {
                item {
                    SensiResultCard(
                        profile = profile,
                        copiedFeedback = copiedFeedback,
                        onCopyAll = {
                            runCatching {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                clipboard?.setPrimaryClip(
                                    ClipData.newPlainText("GRX 2X Sensi", profile.formatForClipboard())
                                )
                                copiedFeedback = true
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun SensiResultCard(
    profile: SensiProfile,
    copiedFeedback: Boolean,
    onCopyAll: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
        border = BorderStroke(1.dp, GrxSecondaryEmerald.copy(alpha = 0.7f)),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("sensi_result_card")
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "${profile.brandName} ${profile.deviceName}",
                        color = GrxTextPrimary,
                        style = MaterialTheme.typography.titleSmall
                    )
                    Text(
                        text = profile.aimStyle.title,
                        color = GrxPrimarySky,
                        style = MaterialTheme.typography.labelSmall
                    )
                }
                Surface(
                    color = GrxEmeraldContainer,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, GrxSecondaryEmerald)
                ) {
                    Text(
                        text = "DPI ${profile.dpiRecomendada}",
                        color = GrxSecondaryEmerald,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            SensiBarRow("Geral (0–200)", profile.geral)
            SensiBarRow("Ponto Vermelho", profile.pontoVermelho)
            SensiBarRow("Mira 2x", profile.mira2x)
            SensiBarRow("Mira 4x", profile.mira4x)
            SensiBarRow("Mira AWM", profile.miraAwm)
            SensiBarRow("Olhadinha", profile.olhadinha)

            Spacer(modifier = Modifier.height(4.dp))

            Button(
                onClick = onCopyAll,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GrxSecondaryEmerald,
                    contentColor = GrxBackground
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("copy_all_sensi_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.ContentCopy,
                    contentDescription = "Copiar sensibilidade",
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (copiedFeedback) "Copiado!" else stringResource(id = R.string.copy_all),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun SensiBarRow(label: String, value: Int) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = label,
                color = GrxTextSecondary,
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = value.toString(),
                color = GrxTextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.labelMedium
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = { (value / 200f).coerceIn(0f, 1f) },
            color = GrxPrimarySky,
            trackColor = GrxBackground,
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}
