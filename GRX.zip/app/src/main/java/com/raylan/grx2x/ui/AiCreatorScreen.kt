package com.raylan.grx2x.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.raylan.grx2x.R
import com.raylan.grx2x.shizuku.ShizukuConnectionState
import com.raylan.grx2x.ui.theme.GrxBackground
import com.raylan.grx2x.ui.theme.GrxCardBorder
import com.raylan.grx2x.ui.theme.GrxCardSurface
import com.raylan.grx2x.ui.theme.GrxElevatedSurface
import com.raylan.grx2x.ui.theme.GrxEmeraldContainer
import com.raylan.grx2x.ui.theme.GrxPrimarySky
import com.raylan.grx2x.ui.theme.GrxPrimarySkyContainer
import com.raylan.grx2x.ui.theme.GrxSecondaryEmerald
import com.raylan.grx2x.ui.theme.GrxTextPrimary
import com.raylan.grx2x.ui.theme.GrxTextSecondary
import com.raylan.grx2x.ui.theme.GrxWarningAmber
import kotlin.math.roundToInt

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiCreatorScreen(
    uiState: GrxUiState,
    shizukuState: ShizukuConnectionState,
    onRequestShizuku: () -> Unit,
    onRefreshDiagnostics: () -> Unit,
    onApplyAiRecommendations: () -> Unit,
    onGoToInjectPanel: () -> Unit
) {
    val isShizukuReady = shizukuState == ShizukuConnectionState.CONNECTED_READY

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(GrxBackground),
        contentAlignment = Alignment.TopCenter
    ) {
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .widthIn(max = 640.dp)
                .fillMaxSize()
        ) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
                    border = BorderStroke(
                        1.dp,
                        if (isShizukuReady) GrxSecondaryEmerald else GrxPrimarySky
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Surface(
                                color = if (isShizukuReady) GrxEmeraldContainer else GrxPrimarySkyContainer,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.size(40.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Icon(
                                        imageVector = if (isShizukuReady) Icons.Filled.CheckCircle else Icons.Filled.Shield,
                                        contentDescription = "Status Shizuku AIDL",
                                        tint = if (isShizukuReady) GrxSecondaryEmerald else GrxPrimarySky,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Shizuku AIDL",
                                    color = GrxTextSecondary,
                                    style = MaterialTheme.typography.labelSmall
                                )
                                Text(
                                    text = if (isShizukuReady) {
                                        stringResource(id = R.string.shizuku_connected)
                                    } else {
                                        stringResource(id = R.string.shizuku_connect)
                                    },
                                    color = if (isShizukuReady) GrxSecondaryEmerald else GrxPrimarySky,
                                    style = MaterialTheme.typography.titleSmall,
                                    modifier = Modifier.testTag("shizuku_status_chip")
                                )
                            }
                        }

                        Button(
                            onClick = onRequestShizuku,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isShizukuReady) GrxEmeraldContainer else GrxPrimarySky,
                                contentColor = if (isShizukuReady) GrxSecondaryEmerald else GrxBackground
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .height(48.dp)
                                .testTag("shizuku_authorize_button")
                        ) {
                            Text(
                                text = if (isShizukuReady) "Ativo" else "Autorizar",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            item {
                val diag = uiState.diagnostics
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
                    border = BorderStroke(1.dp, GrxCardBorder),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = "Assistente IA GRX 2X",
                                    tint = GrxPrimarySky,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Assistente IA GRX 2X",
                                    color = GrxTextPrimary,
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                            IconButton(
                                onClick = onRefreshDiagnostics,
                                modifier = Modifier.testTag("refresh_diagnostics_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = "Atualizar diagnóstico",
                                    tint = GrxPrimarySky
                                )
                            }
                        }

                        if (diag != null) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                TelemetryMetricBox(
                                    icon = Icons.Filled.Memory,
                                    label = "RAM Livre",
                                    value = "${diag.freeRamMb} MB",
                                    subtitle = "${diag.ramUsagePercent}% em uso",
                                    accentColor = GrxPrimarySky,
                                    modifier = Modifier.weight(1f)
                                )
                                TelemetryMetricBox(
                                    icon = Icons.Filled.Thermostat,
                                    label = "Bateria",
                                    value = "${((diag.batteryTempCelsius * 10f).roundToInt() / 10f)}°C",
                                    subtitle = diag.thermalStatusLabel,
                                    accentColor = if (diag.batteryTempCelsius >= 40f) GrxWarningAmber else GrxSecondaryEmerald,
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Surface(
                                color = GrxBackground,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, GrxCardBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = "Modelo analisado: ${diag.analyzedDeviceName}",
                                        color = GrxPrimarySky,
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = diag.reasoning,
                                        color = GrxTextSecondary,
                                        style = MaterialTheme.typography.bodySmall
                                    )
                                }
                            }

                            Text(
                                text = "Funções recomendadas (${diag.recommendedFunctions.size}):",
                                color = GrxTextPrimary,
                                style = MaterialTheme.typography.labelMedium
                            )

                            FlowRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                diag.recommendedFunctions.forEach { fn ->
                                    Surface(
                                        color = GrxElevatedSurface,
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(1.dp, GrxPrimarySky.copy(alpha = 0.5f))
                                    ) {
                                        Text(
                                            text = fn.title,
                                            color = GrxPrimarySky,
                                            style = MaterialTheme.typography.labelSmall,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                        )
                                    }
                                }
                            }

                            Button(
                                onClick = onApplyAiRecommendations,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = GrxSecondaryEmerald,
                                    contentColor = GrxBackground
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("apply_ai_recommendations_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.AutoAwesome,
                                    contentDescription = "Marcar recomendações da IA",
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Aplicar Recomendações com 1 Clique",
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (!uiState.aiFeedbackMessage.isNullOrBlank()) {
                                Surface(
                                    color = GrxEmeraldContainer,
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, GrxSecondaryEmerald),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(
                                            text = uiState.aiFeedbackMessage,
                                            color = GrxTextPrimary,
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        OutlinedButton(
                                            onClick = onGoToInjectPanel,
                                            border = BorderStroke(1.dp, GrxSecondaryEmerald)
                                        ) {
                                            Text(
                                                text = "Ver Painel",
                                                color = GrxSecondaryEmerald,
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GrxCardSurface),
                    border = BorderStroke(1.dp, GrxPrimarySky.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("official_creator_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = GrxPrimarySkyContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.Verified,
                                    contentDescription = "Criador oficial Raylan",
                                    tint = GrxPrimarySky,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = stringResource(id = R.string.creator_card_text),
                                color = GrxTextPrimary,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = stringResource(id = R.string.official_credit_line),
                                color = GrxPrimarySky,
                                fontFamily = FontFamily.Monospace,
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryMetricBox(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    subtitle: String,
    accentColor: androidx.compose.ui.graphics.Color,
    modifier: Modifier = Modifier
) {
    Surface(
        color = GrxBackground,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, GrxCardBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = accentColor,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = label,
                    color = GrxTextSecondary,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                color = GrxTextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = subtitle,
                color = accentColor,
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
