package com.raylan.grx2x.data

import android.os.Build
import com.raylan.grx2x.shizuku.SafeCommandFilter
import kotlin.math.roundToInt

enum class BrandId(
    val displayName: String,
    val subtitle: String,
    val slug: String
) {
    MOTOROLA("Motorola", "Moto G / Edge", "motorola"),
    SAMSUNG("Samsung", "Galaxy A / S / M", "samsung"),
    XIAOMI_POCO("Xiaomi / POCO", "Redmi / POCO", "xiaomi_poco"),
    REALME("Realme", "Realme C / GT / Note", "realme"),
    INFINIX("Infinix", "Hot / Note / GT", "infinix"),
    ASUS("ASUS", "ROG Phone / Zenfone", "asus")
}

data class DeviceModel(
    val id: String,
    val brandId: BrandId,
    val name: String,
    val chipset: String,
    val refreshRateHz: Int,
    val ramGb: Int,
    val touchSamplingHz: Int,
    val defaultDpi: Int,
    val sensitivityFactor: Float
)

enum class GamerFunctionId(
    val title: String,
    val description: String,
    val slug: String
) {
    AIMBOT_NATIVO_2X(
        title = "Aimbot Nativo 2X",
        description = "Calibração extrema de resposta tátil e ponteiro",
        slug = "aimbot_nativo_2x"
    ),
    AIMLOCK_ESTABILIZADOR(
        title = "Aimlock Estabilizador",
        description = "Filtro de tremor de toque e precisão de pixel",
        slug = "aimlock_estabilizador"
    ),
    TRICK_HS_100(
        title = "Trick HS 100%",
        description = "Escala vertical/horizontal de arraste rápido",
        slug = "trick_hs_100"
    ),
    CPU_TURBO_BOOST(
        title = "CPU Turbo Boost",
        description = "Modo de desempenho fixo e prioridade de núcleo",
        slug = "cpu_turbo_boost"
    ),
    GPU_VULKAN_RENDER(
        title = "GPU Vulkan Render",
        description = "Força aceleração gráfica HWUI / Vulkan / OpenGL",
        slug = "gpu_vulkan_render"
    ),
    TOQUE_ZERO_DELAY(
        title = "Toque Zero Delay",
        description = "Redução de long_press_timeout e previsão de movimento",
        slug = "toque_zero_delay"
    ),
    TELA_HZ_CRAVADO(
        title = "Tela 90Hz/120Hz Cravado",
        description = "Taxa de atualização máxima + zero animações",
        slug = "tela_hz_cravado"
    ),
    LIMPEZA_RAM_EXTREMA(
        title = "Limpeza RAM Extrema",
        description = "Liberação de cache global e processos ociosos",
        slug = "limpeza_ram_extrema"
    )
}

enum class GameTarget(
    val label: String,
    val packageName: String
) {
    FF_NORMAL("FF Normal", "com.dts.freefireth"),
    FF_MAX("FF MAX", "com.dts.freefiremax")
}

object DeviceCatalog {

    data class BrandInfo(
        val id: BrandId,
        val displayName: String,
        val subtitle: String,
        val modelCount: Int
    )

    val allModels: List<DeviceModel> = listOf(
        // Motorola (6 modelos)
        DeviceModel("moto_g04", BrandId.MOTOROLA, "Moto G04", "Unisoc T606", 90, 4, 180, 411, 1.06f),
        DeviceModel("moto_g24", BrandId.MOTOROLA, "Moto G24", "Helio G85", 90, 4, 180, 411, 1.05f),
        DeviceModel("moto_g34", BrandId.MOTOROLA, "Moto G34", "Snapdragon 695", 120, 4, 240, 440, 1.02f),
        DeviceModel("moto_g54", BrandId.MOTOROLA, "Moto G54", "Dimensity 7020", 120, 8, 240, 450, 1.01f),
        DeviceModel("moto_g84", BrandId.MOTOROLA, "Moto G84", "Snapdragon 695", 120, 8, 240, 460, 0.99f),
        DeviceModel("moto_edge40", BrandId.MOTOROLA, "Edge 40", "Dimensity 8020", 144, 8, 360, 480, 0.96f),

        // Samsung (6 modelos)
        DeviceModel("sam_a15", BrandId.SAMSUNG, "Galaxy A15", "Helio G99", 90, 4, 180, 411, 1.04f),
        DeviceModel("sam_a25", BrandId.SAMSUNG, "Galaxy A25", "Exynos 1280", 120, 6, 240, 430, 1.02f),
        DeviceModel("sam_a34", BrandId.SAMSUNG, "Galaxy A34", "Dimensity 1080", 120, 6, 240, 445, 1.00f),
        DeviceModel("sam_a54", BrandId.SAMSUNG, "Galaxy A54", "Exynos 1380", 120, 8, 240, 455, 0.98f),
        DeviceModel("sam_s23", BrandId.SAMSUNG, "Galaxy S23", "Snapdragon 8 Gen 2", 120, 8, 240, 490, 0.94f),
        DeviceModel("sam_m14", BrandId.SAMSUNG, "Galaxy M14", "Exynos 1330", 90, 4, 180, 411, 1.05f),

        // Xiaomi / POCO (6 modelos)
        DeviceModel("xia_rn13", BrandId.XIAOMI_POCO, "Redmi Note 13", "Snapdragon 685", 120, 6, 240, 440, 1.01f),
        DeviceModel("xia_r13c", BrandId.XIAOMI_POCO, "Redmi 13C", "Helio G85", 90, 4, 180, 411, 1.06f),
        DeviceModel("poco_x6pro", BrandId.XIAOMI_POCO, "POCO X6 Pro", "Dimensity 8300 Ultra", 120, 12, 480, 500, 0.93f),
        DeviceModel("poco_f5", BrandId.XIAOMI_POCO, "POCO F5", "Snapdragon 7+ Gen 2", 120, 8, 240, 480, 0.95f),
        DeviceModel("xia_rn12", BrandId.XIAOMI_POCO, "Redmi Note 12", "Snapdragon 685", 120, 4, 240, 430, 1.03f),
        DeviceModel("poco_m6pro", BrandId.XIAOMI_POCO, "POCO M6 Pro", "Helio G99 Ultra", 120, 8, 240, 450, 1.00f),

        // Realme (6 modelos)
        DeviceModel("rea_c55", BrandId.REALME, "Realme C55", "Helio G88", 90, 6, 180, 420, 1.04f),
        DeviceModel("rea_c67", BrandId.REALME, "Realme C67", "Snapdragon 685", 90, 8, 180, 430, 1.02f),
        DeviceModel("rea_11x", BrandId.REALME, "Realme 11x", "Dimensity 6100+", 120, 6, 240, 440, 1.01f),
        DeviceModel("rea_note50", BrandId.REALME, "Realme Note 50", "Unisoc T612", 90, 4, 180, 411, 1.07f),
        DeviceModel("rea_12pro_plus", BrandId.REALME, "Realme 12 Pro+", "Snapdragon 7s Gen 2", 120, 8, 240, 470, 0.97f),
        DeviceModel("rea_gt_neo3", BrandId.REALME, "Realme GT Neo 3", "Dimensity 8100", 120, 8, 360, 485, 0.95f),

        // Infinix (6 modelos)
        DeviceModel("inf_hot30i", BrandId.INFINIX, "Hot 30i", "Unisoc T606", 90, 4, 180, 411, 1.07f),
        DeviceModel("inf_hot40pro", BrandId.INFINIX, "Hot 40 Pro", "Helio G99", 120, 8, 240, 450, 1.00f),
        DeviceModel("inf_note30", BrandId.INFINIX, "Note 30", "Helio G99", 120, 8, 240, 445, 1.01f),
        DeviceModel("inf_smart8", BrandId.INFINIX, "Smart 8", "Unisoc T606", 90, 3, 180, 400, 1.08f),
        DeviceModel("inf_gt20pro", BrandId.INFINIX, "GT 20 Pro", "Dimensity 8200 Ultimate", 144, 12, 360, 500, 0.94f),
        DeviceModel("inf_zero30", BrandId.INFINIX, "Zero 30", "Dimensity 8020", 144, 8, 360, 480, 0.96f),

        // ASUS (6 modelos)
        DeviceModel("asus_rog6", BrandId.ASUS, "ROG Phone 6", "Snapdragon 8+ Gen 1", 165, 12, 720, 520, 0.91f),
        DeviceModel("asus_rog7", BrandId.ASUS, "ROG Phone 7", "Snapdragon 8 Gen 2", 165, 16, 720, 540, 0.90f),
        DeviceModel("asus_rog8", BrandId.ASUS, "ROG Phone 8", "Snapdragon 8 Gen 3", 165, 16, 720, 540, 0.89f),
        DeviceModel("asus_zen10", BrandId.ASUS, "Zenfone 10", "Snapdragon 8 Gen 2", 144, 8, 360, 490, 0.94f),
        DeviceModel("asus_zen9", BrandId.ASUS, "Zenfone 9", "Snapdragon 8+ Gen 1", 120, 8, 240, 470, 0.96f),
        DeviceModel("asus_rog5s", BrandId.ASUS, "ROG Phone 5s", "Snapdragon 888+", 144, 12, 360, 500, 0.93f)
    )

    val brands: List<BrandInfo> by lazy {
        BrandId.entries.map {
            BrandInfo(
                id = it,
                displayName = it.displayName,
                subtitle = it.subtitle,
                modelCount = modelsForBrand(it).size
            )
        }
    }

    fun modelsForBrand(brandId: BrandId): List<DeviceModel> =
        allModels.filter { it.brandId == brandId }

    fun detectCurrentDevice(): DeviceModel {
        return runCatching {
            val manufacturer = (Build.MANUFACTURER ?: "").lowercase()
            val brand = (Build.BRAND ?: "").lowercase()
            val model = (Build.MODEL ?: "").lowercase()

            val exactOrPartial = allModels.firstOrNull { candidate ->
                val target = candidate.name.lowercase()
                model.contains(target) || target.contains(model)
            }
            if (exactOrPartial != null) return@runCatching exactOrPartial

            val matchedBrand = when {
                manufacturer.contains("motorola") || brand.contains("moto") -> BrandId.MOTOROLA
                manufacturer.contains("samsung") || brand.contains("samsung") -> BrandId.SAMSUNG
                manufacturer.contains("xiaomi") || brand.contains("redmi") || brand.contains("poco") -> BrandId.XIAOMI_POCO
                manufacturer.contains("realme") || brand.contains("realme") -> BrandId.REALME
                manufacturer.contains("infinix") || brand.contains("infinix") -> BrandId.INFINIX
                manufacturer.contains("asus") || brand.contains("asus") -> BrandId.ASUS
                else -> BrandId.MOTOROLA
            }

            val fallback = modelsForBrand(matchedBrand).first()
            val rawModel = (Build.MODEL ?: "").trim()
            if (rawModel.isNotEmpty()) {
                fallback.copy(
                    id = "auto_${matchedBrand.slug}_${rawModel.replace(Regex("[^A-Za-z0-9]"), "_").lowercase()}",
                    name = rawModel
                )
            } else {
                fallback
            }
        }.getOrElse {
            allModels.first()
        }
    }

    /**
     * Gera exatamente 10 comandos seguros e calibrados por aparelho/marca/chipset para cada uma das 8 funções.
     * Todos os comandos passam obrigatoriamente pelo SafeCommandFilter.
     */
    fun generateSafeCommandsForFunction(
        device: DeviceModel,
        function: GamerFunctionId,
        gamePackage: String
    ): List<String> {
        val pointerSpeed = when {
            device.touchSamplingHz >= 360 -> 5
            device.touchSamplingHz >= 240 -> 6
            else -> 7
        }
        val touchSlope = if (device.sensitivityFactor > 1.02f) 4 else 6
        val hwuiRenderer = if (device.chipset.contains("Snapdragon", ignoreCase = true) ||
            device.chipset.contains("Dimensity", ignoreCase = true)
        ) "skiavk" else "skiagl"
        val refreshRateFloat = "${device.refreshRateHz}.0"
        val trimCacheBytes = if (device.ramGb >= 8) "1073741824" else "2147483648"
        val renderThreads = if (device.ramGb >= 8) "4" else "2"
        val chipsetTag = device.chipset.replace(" ", "_").lowercase()

        val rawCommands = when (function) {
            GamerFunctionId.AIMBOT_NATIVO_2X -> listOf(
                "settings put system pointer_speed $pointerSpeed",
                "settings put secure long_press_timeout 200",
                "settings put secure tap_duration_threshold 0.0",
                "settings put secure touch_exploration_enabled 0",
                "settings put global touch_slop $touchSlope",
                "setprop debug.grx.aim_profile ${device.brandId.slug}_$chipsetTag",
                "setprop persist.sys.touch.pressure.scale ${(0.015f * device.sensitivityFactor).format3()}",
                "setprop debug.touch.sampling_hz ${device.touchSamplingHz}",
                "setprop debug.sf.disable_backpressure 1",
                "cmd game mode performance $gamePackage"
            )

            GamerFunctionId.AIMLOCK_ESTABILIZADOR -> listOf(
                "settings put secure accessibility_enabled 0",
                "settings put system show_touches 0",
                "settings put global window_orientation_listener_log 0",
                "settings put secure multi_press_timeout 220",
                "setprop debug.grx.aimlock_filter ${(1.0f / device.sensitivityFactor).format3()}",
                "setprop persist.sys.ui.hw 1",
                "setprop debug.sf.latch_unsignaled 1",
                "setprop debug.sf.auto_latch_unsignaled 1",
                "setprop debug.hwui.filter_test_overhead false",
                "cmd game mode standard $gamePackage"
            )

            GamerFunctionId.TRICK_HS_100 -> listOf(
                "settings put system pointer_speed 7",
                "settings put global animator_duration_scale 0.0",
                "settings put secure double_tap_timeout 180",
                "settings put system haptic_feedback_enabled 0",
                "setprop debug.grx.trick_hs_ratio ${(1.12f * device.sensitivityFactor).format3()}",
                "setprop debug.grx.dpi_target ${device.defaultDpi}",
                "setprop persist.sys.scrollingcache 3",
                "setprop debug.egl.swapinterval 0",
                "setprop debug.sf.predict_hwc_composition_strategy 1",
                "cmd game mode performance $gamePackage"
            )

            GamerFunctionId.CPU_TURBO_BOOST -> listOf(
                "cmd power set-fixed-performance-mode-enabled true",
                "cmd power set-adaptive-power-saver-enabled false",
                "settings put global low_power 0",
                "settings put global app_standby_enabled 1",
                "settings put global cached_apps_freezer enabled",
                "setprop debug.grx.cpu_profile ${chipsetTag}_turbo",
                "setprop persist.sys.fflag.override.settings_fuse true",
                "setprop debug.performance.tuning 1",
                "setprop debug.hwui.render_dirty_regions false",
                "cmd game mode performance $gamePackage"
            )

            GamerFunctionId.GPU_VULKAN_RENDER -> listOf(
                "setprop debug.hwui.renderer $hwuiRenderer",
                "setprop debug.renderengine.backend ${hwuiRenderer}threaded",
                "setprop debug.egl.hw 1",
                "setprop debug.sf.hw 1",
                "setprop debug.composition.type gpu",
                "setprop debug.hwui.use_buffer_age true",
                "setprop debug.hwui.disable_vsync true",
                "setprop persist.sys.hwui.render_ahead 2",
                "setprop debug.grx.gpu_threads $renderThreads",
                "cmd game mode performance $gamePackage"
            )

            GamerFunctionId.TOQUE_ZERO_DELAY -> listOf(
                "settings put secure long_press_timeout 180",
                "settings put secure multi_press_timeout 180",
                "settings put system accelerometer_rotation 0",
                "settings put system dtmf_tone 0",
                "settings put system sound_effects_enabled 0",
                "setprop debug.grx.touch_zero_delay 1",
                "setprop persist.sys.touch.response_ms 4",
                "setprop debug.sf.early_phase_offset_ns 500000",
                "setprop debug.sf.early_app_phase_offset_ns 500000",
                "setprop debug.sf.high_fps_early_phase_offset_ns 500000"
            )

            GamerFunctionId.TELA_HZ_CRAVADO -> listOf(
                "settings put system peak_refresh_rate $refreshRateFloat",
                "settings put system min_refresh_rate $refreshRateFloat",
                "settings put system user_refresh_rate ${device.refreshRateHz}",
                "settings put global window_animation_scale 0.0",
                "settings put global transition_animation_scale 0.0",
                "settings put global animator_duration_scale 0.0",
                "setprop debug.grx.locked_hz ${device.refreshRateHz}",
                "setprop debug.sf.showupdates 0",
                "setprop debug.sf.enable_gl_backpressure 0",
                "setprop persist.sys.display.fps ${device.refreshRateHz}"
            )

            GamerFunctionId.LIMPEZA_RAM_EXTREMA -> listOf(
                "am kill-all",
                "pm trim-caches $trimCacheBytes",
                "settings put global always_finish_activities 0",
                "settings put global wifi_scan_always_enabled 0",
                "settings put global ble_scan_always_enabled 0",
                "setprop debug.grx.ram_profile ${device.ramGb}gb",
                "setprop persist.sys.purgeable_assets 1",
                "setprop debug.hwui.level 0",
                "setprop debug.sf.max_igbp_list_size 2",
                "cmd game mode performance $gamePackage"
            )
        }

        return SafeCommandFilter.filterSafeCommands(rawCommands)
    }

    private fun Float.format3(): String = ((this * 1000f).roundToInt() / 1000f).toString()
}
