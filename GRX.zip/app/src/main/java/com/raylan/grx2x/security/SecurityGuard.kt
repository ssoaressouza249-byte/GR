package com.raylan.grx2x.security

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.SecurityUpdateWarning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.grx2x.R

object SecurityGuard {

    private const val EXPECTED_PACKAGE = "com.raylan.grx2x"
    private const val EXPECTED_APP_NAME = "GRX 2X"

    data class IntegrityState(
        val isAuthentic: Boolean = true,
        val reason: String? = null
    )

    /**
     * Verifica integridade de pacote e nome visível no onCreate e onResume.
     * Não bloqueia certificados de debug (como os gerados no GitHub Actions).
     */
    fun verifyIntegrity(context: Context): IntegrityState {
        return runCatching {
            val currentPackage = context.packageName
            if (currentPackage != EXPECTED_PACKAGE) {
                return@runCatching IntegrityState(
                    isAuthentic = false,
                    reason = "package_mismatch:$currentPackage"
                )
            }

            val stringAppName = context.getString(R.string.app_name).trim()
            if (stringAppName != EXPECTED_APP_NAME) {
                return@runCatching IntegrityState(
                    isAuthentic = false,
                    reason = "string_app_name_mismatch:$stringAppName"
                )
            }

            val loadedLabel = context.applicationInfo
                .loadLabel(context.packageManager)
                .toString()
                .trim()
            if (loadedLabel != EXPECTED_APP_NAME) {
                return@runCatching IntegrityState(
                    isAuthentic = false,
                    reason = "application_label_mismatch:$loadedLabel"
                )
            }

            IntegrityState(isAuthentic = true)
        }.getOrElse {
            IntegrityState(isAuthentic = false, reason = "verification_error")
        }
    }

    fun triggerUninstallIntent(context: Context) {
        runCatching {
            val uninstallIntent = Intent(
                Intent.ACTION_DELETE,
                Uri.parse("package:${context.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(uninstallIntent)
        }
    }
}

@Composable
fun TamperedLockScreen(
    onUninstallClick: () -> Unit
) {
    BackHandler(enabled = true) {
        // Tela travada: bloqueia o botão voltar em 100%
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFB91C1C))
            .safeDrawingPadding()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 480.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Filled.SecurityUpdateWarning,
                contentDescription = "Alerta de aplicativo modificado",
                tint = Color.White,
                modifier = Modifier.size(72.dp)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "PROTEÇÃO GRX 2X ATIVADA",
                color = Color(0xFFFEE2E2),
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                letterSpacing = 1.2.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = stringResource(id = R.string.security_tamper_message),
                color = Color.White,
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.ExtraBold,
                textAlign = TextAlign.Center,
                modifier = Modifier.testTag("tamper_warning_text")
            )

            Spacer(modifier = Modifier.height(28.dp))

            Button(
                onClick = onUninstallClick,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF991B1B)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("uninstall_now_button")
            ) {
                Text(
                    text = stringResource(id = R.string.security_uninstall_now),
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    letterSpacing = 0.6.sp
                )
            }
        }
    }
}
