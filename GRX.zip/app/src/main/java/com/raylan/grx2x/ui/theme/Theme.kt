package com.raylan.grx2x.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val GrxDarkColorScheme = darkColorScheme(
    primary = GrxPrimarySky,
    onPrimary = GrxBackground,
    primaryContainer = GrxPrimarySkyContainer,
    onPrimaryContainer = GrxPrimarySky,
    secondary = GrxSecondaryEmerald,
    onSecondary = GrxBackground,
    secondaryContainer = GrxEmeraldContainer,
    onSecondaryContainer = GrxSecondaryEmerald,
    background = GrxBackground,
    onBackground = GrxTextPrimary,
    surface = GrxCardSurface,
    onSurface = GrxTextPrimary,
    surfaceVariant = GrxElevatedSurface,
    onSurfaceVariant = GrxTextSecondary,
    outline = GrxCardBorder,
    error = GrxDangerRed,
    onError = GrxTextPrimary
)

val GrxShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(18.dp)
)

@Composable
fun Grx2xTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = GrxDarkColorScheme,
        typography = GrxTypography,
        shapes = GrxShapes,
        content = content
    )
}
