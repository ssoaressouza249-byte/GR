package com.raylan.grx2x.shizuku

object SafeCommandFilter {

    private val forbiddenTokens = listOf(
        "su ",
        "su\t",
        "/su",
        "rm -rf",
        "rm -r",
        "rm ",
        "dd ",
        "format",
        "reboot",
        "flash",
        "/system",
        "/data/data",
        "mkfs",
        "mount ",
        "umount",
        "chmod",
        "chown",
        "&&",
        "||",
        ";",
        "`",
        "$(",
        ">",
        "<",
        "|"
    )

    private val allowedPrefixes = listOf(
        "settings put ",
        "setprop debug.",
        "setprop persist.sys.",
        "cmd power ",
        "cmd game ",
        "pm trim-caches ",
        "am kill-all"
    )

    fun isCommandAllowed(rawCommand: String): Boolean {
        val trimmed = rawCommand.trim()
        if (trimmed.isEmpty()) return false
        if (trimmed == "su") return false

        val normalized = trimmed.lowercase()
        if (forbiddenTokens.any { token -> normalized.contains(token) }) {
            return false
        }

        return allowedPrefixes.any { prefix -> normalized.startsWith(prefix) }
    }

    fun filterSafeCommands(commands: List<String>): List<String> {
        return commands.map { it.trim() }.filter { isCommandAllowed(it) }
    }
}
