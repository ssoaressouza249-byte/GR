package com.raylan.grx2x.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.grx2x.data.AimStyle
import com.raylan.grx2x.data.BrandId
import com.raylan.grx2x.data.DeviceCatalog
import com.raylan.grx2x.data.DeviceDiagnostics
import com.raylan.grx2x.data.DeviceModel
import com.raylan.grx2x.data.DiagnosticSnapshot
import com.raylan.grx2x.data.GameTarget
import com.raylan.grx2x.data.GamerFunctionId
import com.raylan.grx2x.data.SensiCalculator
import com.raylan.grx2x.data.SensiProfile
import com.raylan.grx2x.shizuku.InjectionResult
import com.raylan.grx2x.shizuku.SafeScriptExecutor
import com.raylan.grx2x.shizuku.ShizukuConnectionState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class GrxTab(val label: String) {
    MARCAS_INJETAR("Marcas & Injetar"),
    GERADOR_SENSI("Gerador de Sensi"),
    SISTEMA_IA_CRIADOR("Sistema IA & Criador")
}

data class GrxUiState(
    val activeTab: GrxTab = GrxTab.MARCAS_INJETAR,
    val injectStep: Int = 1,
    val selectedBrand: BrandId? = null,
    val selectedDevice: DeviceModel? = null,
    val selectedFunctions: Set<GamerFunctionId> = emptySet(),
    val selectedGame: GameTarget = GameTarget.FF_NORMAL,
    val isInjecting: Boolean = false,
    val injectionProgress: Int = 0,
    val lastInjectionResult: InjectionResult? = null,
    val sensiDevice: DeviceModel = DeviceCatalog.allModels.first(),
    val sensiAimStyle: AimStyle = AimStyle.PUXADA_RAPIDA_SMG,
    val generatedSensi: SensiProfile? = null,
    val diagnostics: DiagnosticSnapshot? = null,
    val aiFeedbackMessage: String? = null,
    val detectedBannerMessage: String? = null
)

class GrxViewModel(application: Application) : AndroidViewModel(application) {

    private val scriptExecutor = SafeScriptExecutor(application)
    val shizukuState: StateFlow<ShizukuConnectionState> = scriptExecutor.connectionState

    private val _uiState = MutableStateFlow(GrxUiState())
    val uiState: StateFlow<GrxUiState> = _uiState.asStateFlow()

    init {
        scriptExecutor.initialize()
        refreshDiagnostics()
    }

    override fun onCleared() {
        super.onCleared()
        scriptExecutor.dispose()
    }

    fun selectTab(tab: GrxTab) {
        _uiState.update { it.copy(activeTab = tab) }
        if (tab == GrxTab.SISTEMA_IA_CRIADOR) {
            scriptExecutor.refreshShizukuState()
            refreshDiagnostics()
        }
    }

    fun selectBrand(brandId: BrandId) {
        _uiState.update {
            it.copy(
                selectedBrand = brandId,
                injectStep = 2,
                detectedBannerMessage = null,
                lastInjectionResult = null
            )
        }
    }

    fun detectDeviceAutomatically() {
        val detected = DeviceCatalog.detectCurrentDevice()
        _uiState.update {
            it.copy(
                selectedBrand = detected.brandId,
                selectedDevice = detected,
                sensiDevice = detected,
                injectStep = 3,
                detectedBannerMessage = "Aparelho detectado: ${detected.brandId.displayName} ${detected.name}",
                lastInjectionResult = null
            )
        }
        refreshDiagnostics()
    }

    fun selectDevice(device: DeviceModel) {
        _uiState.update {
            it.copy(
                selectedBrand = device.brandId,
                selectedDevice = device,
                sensiDevice = device,
                injectStep = 3,
                detectedBannerMessage = null,
                lastInjectionResult = null
            )
        }
        refreshDiagnostics()
    }

    fun goBackInjectStep() {
        _uiState.update { state ->
            when {
                state.isInjecting -> state
                state.injectStep > 1 -> state.copy(
                    injectStep = state.injectStep - 1,
                    lastInjectionResult = null
                )
                else -> state
            }
        }
    }

    fun toggleFunction(functionId: GamerFunctionId) {
        // Apenas seleciona/desmarca a função — nenhum comando é executado aqui
        _uiState.update { state ->
            val updated = state.selectedFunctions.toMutableSet()
            if (updated.contains(functionId)) {
                updated.remove(functionId)
            } else {
                updated.add(functionId)
            }
            state.copy(selectedFunctions = updated, lastInjectionResult = null)
        }
    }

    fun selectGameTarget(gameTarget: GameTarget) {
        _uiState.update { it.copy(selectedGame = gameTarget, lastInjectionResult = null) }
    }

    fun injectAndOpenGame() {
        val currentState = _uiState.value
        val device = currentState.selectedDevice ?: return
        if (currentState.isInjecting) return

        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    isInjecting = true,
                    injectionProgress = 0,
                    lastInjectionResult = null
                )
            }

            val result = scriptExecutor.injectAndLaunch(
                device = device,
                selectedFunctions = currentState.selectedFunctions,
                gameTarget = currentState.selectedGame,
                onProgress = { progress ->
                    _uiState.update { it.copy(injectionProgress = progress) }
                }
            )

            _uiState.update {
                it.copy(
                    isInjecting = false,
                    injectionProgress = 100,
                    lastInjectionResult = result
                )
            }
        }
    }

    fun dismissInjectionResult() {
        _uiState.update { it.copy(lastInjectionResult = null) }
    }

    fun selectSensiDevice(device: DeviceModel) {
        _uiState.update { it.copy(sensiDevice = device) }
    }

    fun selectSensiAimStyle(aimStyle: AimStyle) {
        _uiState.update { it.copy(sensiAimStyle = aimStyle) }
    }

    fun generateSpecificSensi() {
        val state = _uiState.value
        val profile = SensiCalculator.calculate(state.sensiDevice, state.sensiAimStyle)
        _uiState.update { it.copy(generatedSensi = profile) }
    }

    fun refreshDiagnostics() {
        val activeDevice = _uiState.value.selectedDevice ?: DeviceCatalog.detectCurrentDevice()
        val snapshot = DeviceDiagnostics.analyze(getApplication(), activeDevice)
        _uiState.update { it.copy(diagnostics = snapshot) }
    }

    fun applyAiRecommendations() {
        val activeDevice = _uiState.value.selectedDevice ?: DeviceCatalog.detectCurrentDevice()
        val snapshot = DeviceDiagnostics.analyze(getApplication(), activeDevice)
        _uiState.update {
            it.copy(
                selectedBrand = activeDevice.brandId,
                selectedDevice = activeDevice,
                sensiDevice = activeDevice,
                selectedFunctions = snapshot.recommendedFunctions,
                injectStep = 3,
                diagnostics = snapshot,
                aiFeedbackMessage = "${snapshot.recommendedFunctions.size} funções marcadas automaticamente para ${activeDevice.name}!"
            )
        }
    }

    fun requestShizukuConnection() {
        scriptExecutor.requestShizukuAuthorization()
        scriptExecutor.refreshShizukuState()
    }

    fun refreshShizuku() {
        scriptExecutor.refreshShizukuState()
    }
}
