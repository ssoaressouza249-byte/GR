package com.raylan.grx2x

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.raylan.grx2x.security.SecurityGuard
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Grx2xRobolectricTest {

    @Test
    fun `app name and package pass security guard`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("GRX 2X", context.getString(R.string.app_name))
        assertEquals("com.raylan.grx2x", context.packageName)
        val result = SecurityGuard.verifyIntegrity(context)
        assertTrue(result.isAuthentic)
    }
}
