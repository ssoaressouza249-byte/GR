package com.raylan.grx2x

import com.raylan.grx2x.data.AimStyle
import com.raylan.grx2x.data.BrandId
import com.raylan.grx2x.data.DeviceCatalog
import com.raylan.grx2x.data.GameTarget
import com.raylan.grx2x.data.GamerFunctionId
import com.raylan.grx2x.data.SensiCalculator
import com.raylan.grx2x.shizuku.SafeCommandFilter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class Grx2xUnitTest {

    @Test
    fun `catalog has 6 brands with at least 6 models each`() {
        assertEquals(6, BrandId.entries.size)
        BrandId.entries.forEach { brand ->
            val models = DeviceCatalog.modelsForBrand(brand)
            assertTrue("Brand ${brand.displayName} should have >= 6 models", models.size >= 6)
        }
    }

    @Test
    fun `every gamer function generates 10 safe commands`() {
        val device = DeviceCatalog.allModels.first()
        GamerFunctionId.entries.forEach { fn ->
            val cmds = DeviceCatalog.generateSafeCommandsForFunction(
                device = device,
                function = fn,
                gamePackage = GameTarget.FF_NORMAL.packageName
            )
            assertEquals("Function ${fn.title} must produce 10 safe commands", 10, cmds.size)
            cmds.forEach { cmd ->
                assertTrue("Command must pass SafeCommandFilter: $cmd", SafeCommandFilter.isCommandAllowed(cmd))
            }
        }
    }

    @Test
    fun `safe command filter blocks dangerous and root commands`() {
        val dangerous = listOf(
            "su -c id",
            "rm -rf /data/local/tmp",
            "dd if=/dev/zero of=/dev/block/sda",
            "format userdata",
            "reboot recovery",
            "flash boot boot.img",
            "settings put system test 1; rm -rf /",
            "cat /system/build.prop",
            "ls /data/data/com.dts.freefireth"
        )
        dangerous.forEach { cmd ->
            assertFalse("Dangerous command must be blocked: $cmd", SafeCommandFilter.isCommandAllowed(cmd))
        }
    }

    @Test
    fun `sensi calculator stays within 0 to 200 bounds`() {
        DeviceCatalog.allModels.forEach { device ->
            AimStyle.entries.forEach { style ->
                val profile = SensiCalculator.calculate(device, style)
                assertTrue(profile.geral in 0..200)
                assertTrue(profile.pontoVermelho in 0..200)
                assertTrue(profile.mira2x in 0..200)
                assertTrue(profile.mira4x in 0..200)
                assertTrue(profile.miraAwm in 0..200)
                assertTrue(profile.olhadinha in 0..200)
                assertTrue(profile.dpiRecomendada >= 400)
            }
        }
    }
}
